<div class="footer">
	<div class="slide-inner">
		<a href="<?php echo $host; ?>">Home</a> <!-- Put your links to other pages here --> <a href="<?php echo $host; ?>privacy/" target="_blank">Privacy Policy</a>
		<p class="copyright">&copy; 2023 bmi-finder.com</p><!-- IMPORTANT: Put your domain name here -->
		<a href="https://www.flaticon.com/free-icons/bmi" title="bmi icons">Bmi icons created by DailyPm Studio - Flaticon</a>
	</div>
	<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-0JLP74XDMZ"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'G-0JLP74XDMZ');
</script>
</div>