<?php
	header("Location: https://www.bmi-finder.com/"); //FILL THIS IN WITH YOUR DOMAIN
?>