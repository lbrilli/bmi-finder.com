<div id="menu-burger">&#9776;</div>
<div id="menu-nav">
	<div class="nav-inner">
		<div class="nav-header">Menu</div>
		<a class="nav-item" href="<?php echo $host; ?>">Home</a>
		<div class="nav-divider"></div>
		<!-- Put your links to other pages here -->
		<div class="nav-header">Privacy &amp; Terms</div>
		<a class="nav-item" href="<?php echo $host; ?>privacy/" target="_blank">Privacy Policy</a>
		<div class="nav-divider"></div>
	</div>
</div>
<div id="cover"></div>
